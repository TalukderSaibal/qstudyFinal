<div class="row" style="margin-top:8%;">
<div class="col-md-2"></div>
<div class="col-md-8">
		<div class="well well-lg text-center">
			Sorry there is no question to preview for this module!
		</div>
	</div>
</div>
